package com.example.pm.activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.example.pm.models.MenuManager;
import com.example.progettopm.R;
import com.example.pm.models.FirebaseWrapper;
import com.example.pm.models.PermissionManager;

import java.util.Random;

@SuppressLint("CustomSlashScreen")
public class SplashActivity extends AppCompatActivity {

    private static final String TAG = SplashActivity.class.getCanonicalName();

    private static final int PERMISSION_REQUEST_CODE = (new Random()).nextInt() & Integer.MAX_VALUE;

    MenuManager menu_manager=new MenuManager();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        FirebaseWrapper.Auth auth = new FirebaseWrapper.Auth();
        PermissionManager pm = new PermissionManager(this);

        //check if user is authenticated
        if (!auth.isAuthenticated()) {
            //go to EnterActivity for login or signup
            menu_manager.goToActivity(SplashActivity.this, EnterActivity.class, null);
        }
        if (!pm.askNeededPermissions(PERMISSION_REQUEST_CODE, false) && auth.isAuthenticated() ) {
            menu_manager.goToActivity(SplashActivity.this, MainActivity.class, null);
        }

        this.findViewById(R.id.grantPermission).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!pm.askNeededPermissions(PERMISSION_REQUEST_CODE, true)) {
                    menu_manager.goToActivity(SplashActivity.this, MainActivity.class, null);
                }
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode != PERMISSION_REQUEST_CODE) {
            return;
        }

        for (int res : grantResults) {
            if (res == PackageManager.PERMISSION_DENIED) {
                Log.w(TAG, "A needed permission is not granted!");
                return;
            }
        }

        Log.d(TAG, "All the needed permissions are granted!");
        menu_manager.goToActivity(SplashActivity.this, MainActivity.class, null);
    }
}