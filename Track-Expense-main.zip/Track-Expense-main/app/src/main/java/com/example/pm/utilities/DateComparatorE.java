package com.example.pm.utilities;

import com.example.pm.models.MyExpenses;

import java.util.Comparator;

public class DateComparatorE implements Comparator<MyExpenses> {
    @Override
    public int compare(MyExpenses item1, MyExpenses item2) {
        //compare the dates of item1 and item2
        return item2.getDate().compareTo(item1.getDate());
    }
}
