package com.example.pm.models;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import static com.example.pm.models.GetReminder.getReminder;

import android.Manifest;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.util.Log;

import com.example.pm.activities.SplashActivity;
import com.example.pm.utilities.DateComparatorR;
import com.example.progettopm.R;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class MyWorker extends Worker {
    private final static String TAG = MyWorker.class.getCanonicalName();

    public MyWorker(@NonNull Context context, @NonNull WorkerParameters workerParams) {
        super(context, workerParams);
    }

    @NonNull
    @Override
    public Result doWork() {

        Log.d(TAG, "Reminders Notification---Start process");

        try{
            LocalDate currentDate = LocalDate.now();
            getReminder(new GetReminder.RemindersCallback() {
                @Override
                public void onExpensesLoaded(ArrayList<MyReminders> remindersList) {
                    Collections.sort(remindersList, new DateComparatorR());

                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

                    for (MyReminders reminders : remindersList) {
                        LocalDate dateReminder = LocalDate.parse(reminders.getDate(), formatter);

                        LocalDate dateAfter = currentDate.plusDays(1);

                        // verifica la data
                        if (dateReminder.isEqual(dateAfter)) {
                            Log.d(TAG, "Reminders Notification---A notification has to be sent");
                            sendNotification(reminders.getTitle(), dateReminder.toString());
                        }
                    }
                }
            });
        }

        catch(Exception e){
            Log.e(TAG, "Reminders Notification---Error: "+e);
        }

        return Result.success();
    }

    private void sendNotification(String pTitle, String pDate) {
        try {
            Random rand = new Random();
            // genera un numero casuale tra 0 e 1000
            int notificationId = rand.nextInt(1001);

            Intent intent = new Intent(this.getApplicationContext(), SplashActivity.class);

            PendingIntent pendingIntent = PendingIntent.getActivity(this.getApplicationContext(), 0, intent, PendingIntent.FLAG_IMMUTABLE);

            NotificationCompat.Builder builder = new NotificationCompat.Builder(getApplicationContext(), "notification")
                    .setSmallIcon(R.drawable.piggy_bank)
                    .setContentTitle("Expense Reminder Alert")
                    .setContentText("The expense reminder "+pTitle+" expires on date "+pDate)
                    .setContentIntent(pendingIntent)
                    .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                    .setAutoCancel(true);

            NotificationManagerCompat notificationManager = NotificationManagerCompat.from(getApplicationContext());
            List<String> missingPermissions = new ArrayList<>();
            if (ActivityCompat.checkSelfPermission(this.getApplicationContext(), Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
                Log.d(TAG, "Permission is granted by the user.");
                notificationManager.notify(notificationId, builder.build());
            }
            else {
                missingPermissions.add(null);
            }
        }
        catch (Exception e) {
            Log.e(TAG,"sendNotification---Error: "+e);
        }
    }
}
