package com.example.pm.activities;

import com.bumptech.glide.Glide;
import com.example.pm.fragments.ExpenseListFragment;
import com.example.pm.fragments.ReminderListFragment;
import com.example.pm.fragments.ReminderRecentlyListFragment;
import com.example.pm.models.DBManager;
import com.example.pm.models.FirebaseWrapper;
import com.example.pm.models.MenuManager;
import com.example.pm.models.WorkManager;
import com.example.pm.utilities.Notification;
import com.example.progettopm.R;

import android.app.ProgressDialog;
import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.anychart.AnyChart;
import com.anychart.AnyChartView;
import com.anychart.chart.common.dataentry.DataEntry;
import com.anychart.charts.Pie;
import com.anychart.chart.common.dataentry.ValueDataEntry;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class MainActivity extends AppCompatActivity {

    public DrawerLayout drawerLayout;
    public ActionBarDrawerToggle actionBarDrawerToggle;
    private final static String TAG = MainActivity.class.getCanonicalName();
    FirebaseWrapper.Auth mAuth=new FirebaseWrapper.Auth();
    double xSumHealth=0;
    double xSumFree=0;
    double xSumHouse=0;
    double xSumFood=0;
    double xSumEducation=0;
    double xSumOther=0;
    private String PMAction = null;
    private SwipeRefreshLayout swipeRefreshLayout;
    MenuManager menu_manager=new MenuManager();
    NavigationView menu_main;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        try{
            Notification.createNotificationChannel(this);
            WorkManager.schedulePeriodicWork();

            menu_main=(NavigationView)findViewById(R.id.menu_main_nview);

            /*---Menu Start--*/
            drawerLayout = findViewById(R.id.menu_main);
            actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, R.string.nav_open, R.string.nav_close);
            drawerLayout.addDrawerListener(actionBarDrawerToggle);
            actionBarDrawerToggle.syncState();
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);

            swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);
            swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
                @Override
                public void onRefresh() {
                    loadData();
                }
            });

            TextView empty_chart = findViewById(R.id.empty_chart);
            getDataChart(new GetExpensesDataCallback() {
                @Override
                public void onGetDataExpensesLoaded() {

                    Pie pie = AnyChart.pie();

                    List<DataEntry> data = new ArrayList<>();
                    data.add(new ValueDataEntry("Health", xSumHealth));
                    data.add(new ValueDataEntry("Free Time", xSumFree));
                    data.add(new ValueDataEntry("Household", xSumHouse));
                    data.add(new ValueDataEntry("Food", xSumFood));
                    data.add(new ValueDataEntry("Education", xSumEducation));
                    data.add(new ValueDataEntry("Other", xSumOther));

                    pie.data(data);

                    AnyChartView anyChartView = (AnyChartView) findViewById(R.id.any_chart_view);
                    anyChartView.setChart(pie);

                    if (xSumHealth == 0 && xSumFree == 0 && xSumHouse == 0 && xSumFood == 0 && xSumEducation == 0 && xSumOther == 0) {
                        empty_chart.setVisibility(View.VISIBLE);
                    }


                    anyChartView.setOnRenderedListener(new AnyChartView.OnRenderedListener() {
                        @Override
                        public void onRendered() {
                            // code executed when the chart has been loaded
                            ProgressBar progress_bar=findViewById(R.id.MainProgressBar);

                            progress_bar.setVisibility(View.GONE);
                        }
                    });

                }

            });

            menu_main.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                    menu_manager.ChangeActivity(MainActivity.this, menuItem);

                    return true;
                }
            });

            /*---Menu End--*/

            /*---Action Button add expense---*/
            FloatingActionButton add_button = (FloatingActionButton) findViewById(R.id.add_button);
            add_button.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    Bundle bundle=new Bundle();
                    String xBContent="MainActivity";
                    bundle.putString("caller", xBContent);
                    menu_manager.goToActivity(MainActivity.this, ExpenseActivity.class, bundle);
                }
            });
            /*---Action button end---*/

            Bundle b = getIntent().getExtras();
            if (b != null) {
                PMAction = b.getString("action");
            }

            Fragment rFragment = null;
            rFragment = new ReminderRecentlyListFragment();
            rFragment.setArguments(new Bundle());
            FragmentManager fragmentManager = getSupportFragmentManager();
            fragmentManager.beginTransaction().replace(R.id.frameLayoutR, rFragment, "ReminderRecentlyListFragment").commit();


        }
        catch(Exception e){
           Log.e(TAG, "onCreate---Error: "+e);
        }

        getUserInfo();
    }

    //Menu
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (actionBarDrawerToggle.onOptionsItemSelected(item)) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void goBack(View view) {

        try{
            FragmentManager fragmentManager = getSupportFragmentManager(); // or getFragmentManager() for non-support version
            Fragment fragment = fragmentManager.findFragmentByTag("ExpenseListFragment");
            Fragment fragment_reminder = fragmentManager.findFragmentByTag("ReminderListFragment");

            if (fragment != null) {
                FragmentTransaction transaction = fragmentManager.beginTransaction();
                transaction.remove(fragment);
                transaction.commit();
            }

            if (fragment_reminder != null) {
                FragmentTransaction transaction = fragmentManager.beginTransaction();
                transaction.remove(fragment_reminder);
                transaction.commit();
            }
        }
        catch (Exception e) {
            Log.e(TAG, "goBack---Error: "+e);
        }

    }

    public void getDataChart(GetExpensesDataCallback callback) {

        try {
            //get current user id
            String UserID=mAuth.getUid();

            //get url of database
            String DBUrl = DBManager.GetDBUrl();
            FirebaseDatabase database = FirebaseDatabase.getInstance(DBUrl);

            DatabaseReference reference=database.getReference("expenses");

            reference.child(UserID).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DataSnapshot> task) {
                    if (task.isSuccessful()) {
                        DataSnapshot dataSnapshot = task.getResult();
                        for (DataSnapshot expenseSnapshot : dataSnapshot.getChildren()) {
                            double amount = Double.parseDouble(expenseSnapshot.child("amount").getValue().toString());
                            String category = expenseSnapshot.child("category").getValue().toString();

                            sumExpenses(category, amount);
                        }

                        callback.onGetDataExpensesLoaded();

                    }
                    else {
                        Log.e(TAG, "getDataChart---Error");
                    }

                }
            });
        }

        catch(Exception e) {
            Log.e(TAG, "getDataChart---Error reading data from expenses. Error: " +e);
        }

    }

    public void sumExpenses(String category, double amount) {

        switch (category) {

            case "Health":
                xSumHealth=xSumHealth+amount;
                break;

            case "Free Time":
                xSumFree=xSumFree+amount;
                break;

            case "Household":
                xSumHouse=xSumHouse+amount;
                break;

            case "Food":
                xSumFood=xSumFood+amount;
                break;

            case "Education":
                xSumEducation=xSumEducation+amount;
                break;

            case "Other":
                xSumOther=xSumOther+amount;
                break;

            default:
                xSumOther=xSumOther+amount;
                break;
        }

    }

    public interface GetExpensesDataCallback {
        void onGetDataExpensesLoaded();
    }

    public void openReminder(View view) {
        try{
            Fragment mFragment = null;
            mFragment = new ReminderListFragment();
            FragmentManager fragmentManager = getSupportFragmentManager();
            fragmentManager.beginTransaction().replace(R.id.frameLayout, mFragment, "ReminderListFragment").commit();
        }
        catch (Exception e) {
            Log.e(TAG, "openReminder---Error: "+e);
        }

    }

    public void openExpenses(View view){
        try {
            Bundle bundle=new Bundle();
            String xBContent="MainActivity";
            bundle.putString("caller", xBContent);
            Fragment mFragment = null;
            mFragment = new ExpenseListFragment();
            mFragment.setArguments(bundle);
            FragmentManager fragmentManager = getSupportFragmentManager();
            fragmentManager.beginTransaction()
                    .replace(R.id.frameLayout, mFragment, "ExpenseListFragment").commit();
        }
        catch (Exception e) {
            Log.e(TAG, "openExpenses---Error: "+e);
        }

    }

    private void loadData() {
        menu_manager.goToActivity(MainActivity.this, MainActivity.class, null);
        swipeRefreshLayout.setRefreshing(false);
    }

    public void getUserInfo() {

        try{
            StorageReference storageReferenceRead = FirebaseStorage.getInstance().getReference().child("images/"+mAuth.getUid()+"/Profile_photo.jpg");
            ProgressDialog progressDialog = new ProgressDialog(this);

            ImageView imageView = menu_main.getHeaderView(0).findViewById(R.id.imageProfileMenu);

            storageReferenceRead.getDownloadUrl().addOnSuccessListener(uri -> {
                Glide.with(this)
                        .load(uri)
                        .into(imageView);
            }).addOnFailureListener(exception -> {
                Log.e(TAG, "getUserInfo---Error: "+exception.getMessage());
            });

        }
        catch(Exception e){
            Log.e(TAG, "getUserInfo---Error: "+e);
        }

        TextView nameProfile = menu_main.getHeaderView(0).findViewById(R.id.nameMenu);

        try {
            //get current user id
            String UserID=mAuth.getUid();

            //get url of database
            String DBUrl = DBManager.GetDBUrl();
            FirebaseDatabase database = FirebaseDatabase.getInstance(DBUrl);

            DatabaseReference reference=database.getReference("users");

            reference.child(UserID).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DataSnapshot> task) {

                    if(task.isSuccessful()){
                        DataSnapshot dataSnapshot= task.getResult();
                        String xFirstName=String.valueOf(dataSnapshot.child("firstname").getValue());
                        String xLastName=String.valueOf(dataSnapshot.child("lastname").getValue());
                        nameProfile.setText(xFirstName + " " + xLastName);
                    }
                }
            });
        }
        catch(Exception e) {
            Log.e(TAG, "Error reading data from user profile." +e);
        }

    }
}