package com.example.pm.activities;

import com.bumptech.glide.Glide;
import com.example.pm.fragments.ReminderListFragment;
import com.example.pm.models.DBManager;
import com.example.pm.models.FirebaseWrapper;
import com.example.pm.models.GetReminder;
import com.example.pm.models.MenuManager;
import com.example.pm.models.MyReminders;
import com.example.progettopm.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class ReminderActivity extends AppCompatActivity {

    private DrawerLayout drawerLayout;
    private ActionBarDrawerToggle actionBarDrawerToggle;
    private MenuManager menu_manager = new MenuManager();
    private String xId=null;
    private String xId_exp=null;
    private TextView Date;
    private String xExpenseTitle;
    private String xAmount;
    private String xCategory;
    private String xCategoryExtra;
    private String xDate;
    private String xNote;
    private Calendar calendar;
    private String PMAction;
    private static final String TAG = ReminderActivity.class.getCanonicalName();

    NavigationView menu_main;
    FirebaseWrapper.Auth mAuth=new FirebaseWrapper.Auth();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reminder);

        menu_main = (NavigationView) findViewById(R.id.menu_main_reminder);

        menu_main.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                menu_manager.ChangeActivity(ReminderActivity.this, item);
                return true;
            }
        });

        try{
            Bundle b = getIntent().getExtras();
            if(b != null) {
                PMAction = b.getString("action");
            }
            //opens recycler or edit based on bundle
            if(PMAction.equals("Recycler")){

                drawerLayout = findViewById(R.id.menu_reminder);
                actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, R.string.nav_open, R.string.nav_close);
                drawerLayout.addDrawerListener(actionBarDrawerToggle);
                actionBarDrawerToggle.syncState();
                getSupportActionBar().setDisplayHomeAsUpEnabled(true);

                //go to fragment
                Bundle bundle = new Bundle();
                bundle.putString("caller", "ReminderActivity");

                Fragment mFragment = null;
                mFragment = new ReminderListFragment();
                mFragment.setArguments(bundle);
                FragmentManager fragmentManager = getSupportFragmentManager();
                fragmentManager.beginTransaction().replace(R.id.frameLayout, mFragment, "ReminderListFragment").commit();
                TextView reminder_title=findViewById(R.id.RA_title);
                reminder_title.setVisibility(View.GONE);

            }
            else if(PMAction.equals("EDIT")){

                ActionBar actionBar_back = getSupportActionBar();
                actionBar_back.setDisplayHomeAsUpEnabled(true);

                //edit date reminder
                setContentView(R.layout.reminder_view_layout);
                xId = b.getString("id");
                if(xId!=null){
                    GetReminder.getReminderRecord(new GetReminder.ReminderCallback() {
                        @Override
                        public void onReminderLoaded(MyReminders reminder, String pId) {

                            try{
                                xId_exp=reminder.getIdExp();
                                xExpenseTitle=reminder.getTitle();
                                xAmount= reminder.getAmount();
                                xCategory= reminder.getCategory();
                                xCategoryExtra= reminder.getCategoryExtra();
                                xDate= reminder.getDate();
                                xNote=reminder.getNotes();

                                TextView E_expense_title=findViewById(R.id.R_expense_title);
                                TextView E_amount=findViewById(R.id.R_amount);
                                TextView E_category_extra=findViewById(R.id.R_category_extra);
                                Spinner E_category=findViewById(R.id.R_category_spinner);
                                Date=findViewById(R.id.R_date);

                                E_expense_title.setText(xExpenseTitle);
                                E_amount.setText(xAmount);
                                E_category.setSelection(getSpinnerIdByName(xCategory));
                                E_category_extra.setText(xCategoryExtra);
                                Date.setText(xDate);

                                E_category.setEnabled(false);

                                if(xCategory.equals("Other")){
                                    E_category_extra.setVisibility(View.VISIBLE);
                                }
                                else{
                                    E_category_extra.setVisibility(View.GONE);
                                }

                                Date.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        showDatePickerDialog();
                                    }
                                });

                                calendar=Calendar.getInstance();
                            }
                            catch(Exception e){
                                Log.e(TAG, "Error reading reminder from database"+e);
                            }


                        }
                    }, xId);
                }


            }
        }
        catch(Exception e) {
            Log.e(TAG, "onCreate---Error: "+e);
        }

        getUserInfo();
    }

    private int getSpinnerIdByName(String pName){
        int xPosition=0;
        try{
            switch (pName) {
                case "Free Time":
                    xPosition=1;
                    break;
                case "Household":
                    xPosition=2;
                    break;
                case "Food":
                    xPosition=3;
                    break;
                case "Education":
                    xPosition=4;
                    break;
                case "Health":
                    xPosition=5;
                    break;
                case "Other":
                    xPosition=6;
                    break;

                default:
                    xPosition=0;
                    break;
            }
            return xPosition;
        }
        catch(Exception e) {
            Log.e(TAG, "getSpinnerIdByName---Error: "+e);
            return xPosition;
        }

    }

    //used to set date with calendar
    private void showDatePickerDialog() {
        try{
            DatePickerDialog datePickerDialog = new DatePickerDialog(
                    this,
                    new DatePickerDialog.OnDateSetListener() {
                        @Override
                        public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                            calendar.set(Calendar.YEAR, year);
                            calendar.set(Calendar.MONTH, month);
                            calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                            updateSelectedDate();
                        }
                    },
                    calendar.get(Calendar.YEAR),
                    calendar.get(Calendar.MONTH),
                    calendar.get(Calendar.DAY_OF_MONTH));

            datePickerDialog.show();
        }
        catch(Exception e){
           Log.e(TAG, "showDatePickerDialog---Error: "+e);
        }

    }

    private void updateSelectedDate() {
        try{
            String dateFormat = "dd-MM-yyyy";
            SimpleDateFormat sdf = new SimpleDateFormat(dateFormat, Locale.US);
            String formattedDate = sdf.format(calendar.getTime());
            Date.setText(formattedDate);
        }
        catch (Exception e){
            Log.e(TAG, "updateSelectedDate---Error: "+e);
        }
    }

    public void Save(View view){
        try{
            String xxDate=Date.getText().toString();

            MyReminders myr=new MyReminders(xId, xId_exp,xExpenseTitle,Double.parseDouble(xAmount), xCategory, xCategoryExtra, xxDate, xNote );
            myr.Save();

            Bundle bundle= new Bundle();
            bundle.putString("action", "Recycler");
            menu_manager.goToActivity(ReminderActivity.this, ReminderActivity.class, bundle);
            Toast.makeText(view.getContext(), this.getString(R.string.RA_toast_ok), Toast.LENGTH_LONG).show();
        }
        catch(Exception e) {
            Log.e(TAG, "Save---Error: "+e);
        }
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        try{
            if(PMAction.contains("Recycler")){
                if (actionBarDrawerToggle.onOptionsItemSelected(item)) {
                    return true;
                }
                return super.onOptionsItemSelected(item);
            }
            else if(PMAction.contains("EDIT")){
                int id = item.getItemId();
                if (id == android.R.id.home) {
                    onBackPressed();
                    return true;
                }
                return super.onOptionsItemSelected(item);
            }
            return false;
        }
        catch(Exception e){
           Log.e(TAG, "onOptionsItemSelected---Error: "+e);
            return false;
        }
    }

    public void getUserInfo() {

        try{
            StorageReference storageReferenceRead = FirebaseStorage.getInstance().getReference().child("images/"+mAuth.getUid()+"/Profile_photo.jpg");
            ProgressDialog progressDialog = new ProgressDialog(this);

            ImageView imageView = menu_main.getHeaderView(0).findViewById(R.id.imageProfileMenu);

            storageReferenceRead.getDownloadUrl().addOnSuccessListener(uri -> {
                Glide.with(this)
                        .load(uri)
                        .into(imageView);
            }).addOnFailureListener(exception -> {
                Log.e(TAG, "getUserInfo---Error: "+exception.getMessage());
            });

        }
        catch(Exception e){
            Log.e(TAG, "getUserInfo---Error: "+e);
        }

        TextView nameProfile = menu_main.getHeaderView(0).findViewById(R.id.nameMenu);

        try {
            //get current user id
            String UserID=mAuth.getUid();

            //get url of database
            String DBUrl = DBManager.GetDBUrl();
            FirebaseDatabase database = FirebaseDatabase.getInstance(DBUrl);

            DatabaseReference reference=database.getReference("users");

            reference.child(UserID).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DataSnapshot> task) {

                    if(task.isSuccessful()){
                        DataSnapshot dataSnapshot= task.getResult();
                        String xFirstName=String.valueOf(dataSnapshot.child("firstname").getValue());
                        String xLastName=String.valueOf(dataSnapshot.child("lastname").getValue());
                        nameProfile.setText(xFirstName + " " + xLastName);
                    }
                }
            });
        }
        catch(Exception e) {
            Log.e(TAG, "Error reading data from user profile." +e);
        }

    }
}