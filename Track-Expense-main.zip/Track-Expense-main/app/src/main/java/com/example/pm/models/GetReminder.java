package com.example.pm.models;

import android.util.Log;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;


public class GetReminder {

    private final static String TAG = GetReminder.class.getCanonicalName();

    public static void getReminder(RemindersCallback callback) {
        ArrayList<MyReminders> remindersList = new ArrayList<MyReminders>();
        FirebaseWrapper.Auth mAuth = new FirebaseWrapper.Auth();

        try {
            String UserID = mAuth.getUid();

            String DBUrl = DBManager.GetDBUrl();
            FirebaseDatabase database = FirebaseDatabase.getInstance(DBUrl);

            DatabaseReference reference = database.getReference("reminders");

            reference.child(UserID).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DataSnapshot> task) {
                    if (task.isSuccessful()) {
                        DataSnapshot dataSnapshot = task.getResult();
                        for (DataSnapshot reminderSnapshot : dataSnapshot.getChildren()) {
                            String id = reminderSnapshot.getKey().toString();
                            String id_exp = reminderSnapshot.child("id_exp").getValue().toString();
                            String expense_title = reminderSnapshot.child("title_expense").getValue().toString();
                            double amount = Double.parseDouble(reminderSnapshot.child("amount").getValue().toString());
                            String category = reminderSnapshot.child("category").getValue().toString();
                            String category_extra = reminderSnapshot.child("category_extra").getValue().toString();
                            String date_reminder = reminderSnapshot.child("date").getValue().toString();
                            String notes = reminderSnapshot.child("notes").getValue().toString();

                            MyReminders reminder = new MyReminders(id, id_exp, expense_title, amount, category, category_extra, date_reminder, notes);

                            remindersList.add(reminder);
                        }
                        callback.onExpensesLoaded(remindersList);
                    }
                }
            });
        }
        catch (Exception e) {
            Log.e(TAG, "Error reading reminder. Error: " + e);
        }
    }

    public interface RemindersCallback {
        void onExpensesLoaded(ArrayList<MyReminders> remindersList);
    }

    public static void getReminderRecord(ReminderCallback callback, String pId) {
        FirebaseWrapper.Auth mAuth = new FirebaseWrapper.Auth();
        MyReminders reminder;

        try {
            String UserID = mAuth.getUid();

            String DBUrl = DBManager.GetDBUrl();
            FirebaseDatabase database = FirebaseDatabase.getInstance(DBUrl);

            DatabaseReference reference = database.getReference("reminders");

            reference.child(UserID).child(pId).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DataSnapshot> task) {
                    if (task.isSuccessful()) {
                        DataSnapshot dataSnapshot = task.getResult();
                        String id = dataSnapshot.getKey().toString();
                        String id_exp = dataSnapshot.child("id_exp").getValue().toString();
                        String expense_title = dataSnapshot.child("title_expense").getValue().toString();
                        double amount = Double.parseDouble(dataSnapshot.child("amount").getValue().toString());
                        String category = dataSnapshot.child("category").getValue().toString();
                        String category_extra = dataSnapshot.child("category_extra").getValue().toString();
                        String date_reminder = dataSnapshot.child("date").getValue().toString();
                        String notes = dataSnapshot.child("notes").getValue().toString();

                        MyReminders reminder = new MyReminders(id, id_exp, expense_title, amount, category, category_extra, date_reminder, notes);

                        callback.onReminderLoaded(reminder, pId);
                    }
                }
            });
        }
        catch (Exception e) {
            Log.e(TAG,"Error reading reminder. Error: "+e);
        }
    }

    public interface ReminderCallback {
        void onReminderLoaded(MyReminders reminder, String pId);

    }

    public static void getRemindersRecently(RemindersRecentlyCallback callback) {
        ArrayList<MyReminders> remindersList = new ArrayList<MyReminders>();
        FirebaseWrapper.Auth mAuth = new FirebaseWrapper.Auth();
        try {
            String UserID = mAuth.getUid();

            String DBUrl = DBManager.GetDBUrl();
            FirebaseDatabase database = FirebaseDatabase.getInstance(DBUrl);

            DatabaseReference reference = database.getReference("reminders");

            reference.child(UserID).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DataSnapshot> task) {
                    if (task.isSuccessful()) {
                        DataSnapshot dataSnapshot = task.getResult();

                        for (DataSnapshot reminderSnapshot : dataSnapshot.getChildren()) {
                            String id = reminderSnapshot.getKey().toString();
                            String id_exp = reminderSnapshot.child("id_exp").getValue().toString();
                            String expense_title = reminderSnapshot.child("title_expense").getValue().toString();
                            double amount = Double.parseDouble(reminderSnapshot.child("amount").getValue().toString());
                            String category = reminderSnapshot.child("category").getValue().toString();
                            String category_extra = reminderSnapshot.child("category_extra").getValue().toString();
                            String date_reminder = reminderSnapshot.child("date").getValue().toString();
                            String notes = reminderSnapshot.child("notes").getValue().toString();

                            MyReminders reminder = new MyReminders(id, id_exp, expense_title, amount, category, category_extra, date_reminder, notes);
                            remindersList.add(reminder);
                        }

                        callback.onRemindersRecentlyLoaded(remindersList);
                    }
                }
            });
        }
        catch (Exception e) {
            Log.e(TAG, "Error reading reminder. Error: " + e);
        }
    }

    public interface RemindersRecentlyCallback {
        void onRemindersRecentlyLoaded(ArrayList<MyReminders> remindersList);
    }

}
