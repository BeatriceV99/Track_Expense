package com.example.pm.fragments;

import static com.example.pm.models.GetReminder.getReminder;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.pm.adapters.ReminderListAdapter;
import com.example.pm.models.DBManager;
import com.example.pm.models.FirebaseWrapper;
import com.example.pm.models.GetReminder;
import com.example.pm.models.MyReminders;
import com.example.pm.utilities.DateComparatorR;
import com.example.progettopm.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;

public class ReminderListFragment extends Fragment {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private String mParam1;
    private String mParam2;

    private final static String TAG = ReminderListFragment.class.getCanonicalName();
    final String[] xCategory = {null};
    int xMonth;
    final String[] xYear = {null};
    ReminderListAdapter itemAdapter;
    Calendar calendar = Calendar.getInstance();
    String xCurrentYear = Integer.toString(calendar.get(Calendar.YEAR));
    int xCurrentMonth= calendar.get(Calendar.MONTH)+1;
    TextView empty_reminder;

    public ReminderListFragment() {
        // Required empty public constructor
    }

    public static ReminderListFragment newInstance(String param1, String param2) {
        ReminderListFragment fragment = new ReminderListFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_reminder_list, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {

        try{
            Bundle arguments = getArguments();
            if (arguments != null) {
                String xCaller = arguments.getString("caller");

                if(xCaller.equals("ReminderActivity")){
                    FloatingActionButton close_button=view.findViewById(R.id.closeButton);
                    close_button.setVisibility(View.GONE);
                }
            }
            super.onViewCreated(view, savedInstanceState);

            Context PMContext = getContext();
            Spinner SPCategory = view.findViewById((R.id.filter_category_reminder));
            Spinner SPMonth = view.findViewById((R.id.filter_month_reminder));
            Spinner SPYear = view.findViewById((R.id.filter_year_reminder));

            final boolean[] bFirstLoad1 = {true};
            final boolean[] bFirstLoad2 = {true};
            final boolean[] bFirstLoad3 = {true};

            SPMonth.setSelection(xCurrentMonth);
            SPYear.setSelection(0);

            populateYearSpinner(PMContext, SPYear);

            empty_reminder = view.findViewById(R.id.empty_reminder1);

            getReminder(new GetReminder.RemindersCallback() {
                @Override
                public void onExpensesLoaded(ArrayList<MyReminders> remindersList) {
                    Collections.sort(remindersList, new DateComparatorR());
                    itemAdapter = new ReminderListAdapter(remindersList, PMContext);
                    RecyclerView recyclerView = view.findViewById(R.id.recycler_view_reminder);
                    recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
                    recyclerView.setAdapter(itemAdapter);

                    ProgressBar progress_bar=view.findViewById(R.id.progressBar_reminder);

                    progress_bar.setVisibility(View.GONE);

                    if (remindersList.isEmpty()) {
                        empty_reminder.setVisibility(View.VISIBLE);
                    }
                }
            });

            SPCategory.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {

                    if(position==0){
                        xCategory[0]=null;
                    }
                    else{
                        xCategory[0] = SPCategory.getSelectedItem().toString();
                    }

                    if(!bFirstLoad1[0]) {
                        filterRecycler();
                    }
                    bFirstLoad1[0] =false;

                }

                @Override
                public void onNothingSelected(AdapterView<?> adapterView) {
                    xCategory[0] = null;
                }
            });

            SPMonth.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {

                    xMonth=position;
                    if(!bFirstLoad2[0]) {
                        filterRecycler();
                    }
                    else {
                        xMonth=xCurrentMonth;
                        filterRecycler();
                    }
                    bFirstLoad2[0] =false;

                }

                @Override
                public void onNothingSelected(AdapterView<?> adapterView) {
                    xMonth=xCurrentMonth;
                }

            });

            SPYear.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {

                    xYear[0] = SPYear.getSelectedItem().toString();
                    if(!bFirstLoad3[0]) {
                        filterRecycler();
                    }
                    else {
                        xYear[0]=xCurrentYear;
                        filterRecycler();
                    }
                    bFirstLoad3[0] =false;

                }

                @Override
                public void onNothingSelected(AdapterView<?> adapterView) {
                    xYear[0]=xCurrentYear;
                }

            });
        }
        catch (Exception e) {
            Log.e(TAG, "onViewCreated---Error: "+e);
        }
    }

    private void filterRecycler(){
        if(itemAdapter!=null){
            itemAdapter.filter(xCategory[0], xMonth, xYear[0]);
        }

    }

    private void populateYearSpinner(Context pContext, Spinner pSpinner) {

        FirebaseWrapper.Auth mAuth=new FirebaseWrapper.Auth();
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        final String[] xYear = {null};

        try {

            //get current user id
            String UserID = mAuth.getUid();

            //get url of database
            String DBUrl = DBManager.GetDBUrl();
            FirebaseDatabase database = FirebaseDatabase.getInstance(DBUrl);

            DatabaseReference reference = database.getReference("reminders");

            reference.child(UserID).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DataSnapshot> task) {
                    if (task.isSuccessful()) {
                        DataSnapshot dataSnapshot = task.getResult();
                        HashSet<String> yearsSet = new HashSet<String>();
                        for (DataSnapshot expenseSnapshot : dataSnapshot.getChildren()) {

                            String date = expenseSnapshot.child("date").getValue().toString();
                            Date xDate = null;
                            try {
                                xDate = dateFormat.parse(date);
                            } catch (ParseException e) {
                                throw new RuntimeException(e);
                            }
                            Calendar cal = Calendar.getInstance();
                            cal.setTime(xDate);
                            xYear[0] = Integer.toString(cal.get(Calendar.YEAR));

                            if (xYear[0] != null) {
                                yearsSet.add(xYear[0]);
                            }

                        }

                        //convert set to list
                        ArrayList<String> yearsList = new ArrayList<>(yearsSet);
                        //sort the list in descending order
                        Collections.sort(yearsList, Collections.reverseOrder());

                        // Create an ArrayAdapter and set it to the Spinner
                        ArrayAdapter<String> adapter = new ArrayAdapter<String>(pContext, android.R.layout.simple_spinner_item, yearsList);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        pSpinner.setAdapter(adapter);

                    }
                }
            });
        }
        catch (Exception e) {
            Log.e(TAG,"populateYearSpinner---Error: "+e);
        }

    }
}