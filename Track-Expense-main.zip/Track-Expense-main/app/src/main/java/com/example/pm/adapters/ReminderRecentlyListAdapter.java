package com.example.pm.adapters;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.pm.models.MyReminders;
import com.example.progettopm.R;

import java.util.ArrayList;

public class ReminderRecentlyListAdapter extends RecyclerView.Adapter<ReminderRecentlyListAdapter.ViewHolder> {
    private ArrayList<MyReminders> reminder_recently_list;
    private Context PMContext;
    private ArrayList<MyReminders> recentlyReminderList;
    private final static String TAG = ReminderRecentlyListAdapter.class.getCanonicalName();
    private int xShowCount;

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private final TextView Title;
        private final TextView Date;

        public ViewHolder(View itemView) {
            super(itemView);

            Title = itemView.findViewById(R.id.eventRecentlyTitle);
            Date = itemView.findViewById(R.id.eventRecentlyDate);
        }
    }

    public ReminderRecentlyListAdapter(ArrayList<MyReminders> reminder_listR, Context contextR, int pShowCount) {
        this.reminder_recently_list = reminder_listR;
        this.recentlyReminderList = reminder_listR;
        this.PMContext = contextR;
        this.xShowCount=pShowCount;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.reminder_recently_layout, parent, false);
        return new ViewHolder(itemView);
    }

    @Override
    public int getItemCount() {
        //return the number of items to display
        return Math.min(xShowCount, reminder_recently_list.size());
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        try {
            int xPosition = position;
            MyReminders recentlyReminder = reminder_recently_list.get(position);
            holder.Title.setText(recentlyReminder.getTitle());
            holder.Date.setText(recentlyReminder.getDate());
        }
        catch (Exception e) {
            Log.e(TAG, "Error in onBindViewHolder. Error: " + e);
        }
    }

}
