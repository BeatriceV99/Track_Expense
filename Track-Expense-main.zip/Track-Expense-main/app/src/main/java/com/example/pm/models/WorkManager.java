package com.example.pm.models;

import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.PeriodicWorkRequest;

import java.util.concurrent.TimeUnit;

public class WorkManager {
    public static void schedulePeriodicWork() {

        Constraints constraints = new Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build();

        PeriodicWorkRequest periodicWorkRequest = new PeriodicWorkRequest.Builder(MyWorker.class, 3, TimeUnit.HOURS).setConstraints(constraints).build();

        androidx.work.WorkManager.getInstance().enqueueUniquePeriodicWork(
                "reminder_notify",
                ExistingPeriodicWorkPolicy.KEEP,
                periodicWorkRequest
        );
    }
}
