package com.example.pm.utilities;

import com.example.pm.models.MyReminders;

import java.util.Comparator;

public class DateComparatorR implements Comparator<MyReminders> {
    @Override
    public int compare(MyReminders item1, MyReminders item2) {
        //compare the dates of item1 and item2
        return item1.getDate().compareTo(item2.getDate());
    }
}