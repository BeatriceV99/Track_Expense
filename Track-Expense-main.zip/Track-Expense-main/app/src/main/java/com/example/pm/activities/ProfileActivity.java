package com.example.pm.activities;

import com.example.pm.models.DBManager;
import com.example.pm.models.FirebaseWrapper;
import com.example.pm.models.MenuManager;
import com.example.progettopm.R;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Button;
import android.app.ProgressDialog;
import android.net.Uri;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.navigation.NavigationView;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import com.bumptech.glide.Glide;

public class ProfileActivity extends AppCompatActivity {

    private final static String TAG = ProfileActivity.class.getCanonicalName();
    Context PMContext;
    FirebaseWrapper.Auth mAuth=new FirebaseWrapper.Auth();
    public DrawerLayout drawerLayout;
    public ActionBarDrawerToggle actionBarDrawerToggle;
    private static final int PICK_IMAGE_REQUEST = 1;
    private StorageReference storageReference;
    private StorageReference storageReferenceRead;
    private Uri imageUri;
    private ProgressDialog progressDialog;
    ImageView imageView;
    String xFirstNameStart="";
    String xFirstNameEnd="";
    String xLastNameStart="";
    String xLastNameEnd="";
    String xEmailStart="";
    String xEmailEnd="";

    NavigationView menu_main;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        PMContext=getBaseContext();

        imageView = (ImageView) findViewById(R.id.selectedImageView);

        menu_main=(NavigationView)findViewById(R.id.menu_main_profile);
        MenuManager menu_manager=new MenuManager();

        drawerLayout = findViewById(R.id.menu_profile);
        actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, R.string.nav_open, R.string.nav_close);

        // pass the Open and Close toggle for the drawer layout listener
        // to toggle the button
        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();

        // to make the Navigation drawer icon always appear on the action bar
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        menu_main.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                menu_manager.ChangeActivity(ProfileActivity.this, menuItem);

                return true;
            }
        });

        EditText firstnameProfile=(EditText)findViewById(R.id.firstnameProfile);
        EditText lastnameProfile=(EditText)findViewById(R.id.lastnameProfile);
        EditText emailAddress=(EditText)findViewById(R.id.emailAddress);
        EditText passwordOld=(EditText)findViewById(R.id.passwordOld);
        Button save_button=(Button)findViewById(R.id.button_save_profile);

        try {
            //get current user id
            String UserID=mAuth.getUid();

            //get url of database
            String DBUrl = DBManager.GetDBUrl();
            FirebaseDatabase database = FirebaseDatabase.getInstance(DBUrl);

            DatabaseReference reference=database.getReference("users");

            reference.child(UserID).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DataSnapshot> task) {

                    if(task.isSuccessful()){
                        DataSnapshot dataSnapshot= task.getResult();
                        xFirstNameStart=String.valueOf(dataSnapshot.child("firstname").getValue());
                        xLastNameStart=String.valueOf(dataSnapshot.child("lastname").getValue());
                        xEmailStart=String.valueOf(dataSnapshot.child("email").getValue());
                        firstnameProfile.setText(xFirstNameStart);
                        lastnameProfile.setText(xLastNameStart);
                        emailAddress.setText(xEmailStart);
                    }
                    else{
                       Log.e(TAG, "onCreate---Error reading user profile data from firebase. Error: "+task.getException().getMessage());
                    }
                }
            });
        }
        catch(Exception e) {
            Log.e(TAG, "Error reading data from user profile." +e);
        }
        //if save button clicked
        save_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                final boolean[] bError = {false};

                try{
                    if (firstnameProfile.getText().toString().isEmpty()){
                        firstnameProfile.setError(getString(R.string.errorFirstname));
                        bError[0] =true;
                    }
                    if (lastnameProfile.getText().toString().isEmpty()){
                        lastnameProfile.setError(getString(R.string.errorLastname));
                        bError[0] =true;
                    }
                    if (emailAddress.getText().toString().isEmpty()){
                        emailAddress.setError(getString(R.string.errorEmail));
                        bError[0] =true;
                    }
                }
                catch (Exception e){
                    Log.e(TAG,"save_button onClick---Error: "+e);
                    bError[0] =true;
                }

                if(!bError[0]) {

                    try {

                        xEmailEnd=emailAddress.getText().toString();

                        //update password
                        if(!passwordOld.getText().toString().isEmpty()){
                            //check if password not equal to current password
                            mAuth.checkPasswordProfile(new FirebaseWrapper.Auth.CheckPasswordProfileCallback() {
                                @Override
                                public void onPasswordChecked(boolean pRetval) {
                                    if(!pRetval){
                                       bError[0] =true;
                                        Toast.makeText(PMContext, "Error! Password equal to current password!", Toast.LENGTH_LONG).show();
                                    }
                                    else {
                                        mAuth.UpdateUserAuth(new FirebaseWrapper.Auth.ChangeEmailPasswordCallback() {
                                            @Override
                                            public void onChangeSent(String pRetval) {
                                                Toast.makeText(PMContext, pRetval, Toast.LENGTH_LONG).show();

                                                if(pRetval.contains("Log in again") || pRetval.contains("sign in again")){
                                                    //go to login
                                                    Toast.makeText(PMContext, "Redirecting to login...", Toast.LENGTH_LONG).show();
                                                    try {
                                                        Thread.sleep(3000);
                                                    } catch (InterruptedException e) {

                                                    }
                                                    mAuth.signOut();
                                                    menu_manager.goToActivity(ProfileActivity.this, SplashActivity.class, null);
                                                }
                                            }
                                        }, "", passwordOld.getText().toString());
                                    }
                                }
                            },emailAddress.getText().toString(), passwordOld.getText().toString() );

                        }

                        //update email
                        if(!xEmailEnd.equals(xEmailStart) && !xEmailEnd.isEmpty() ){
                            //change only email
                            mAuth.UpdateUserAuth(new FirebaseWrapper.Auth.ChangeEmailPasswordCallback() {
                                @Override
                                public void onChangeSent(String pRetval) {
                                    Toast.makeText(PMContext, pRetval, Toast.LENGTH_LONG).show();

                                    if(pRetval.contains("Log in again") || pRetval.contains("sign in again")){
                                        //go to login
                                        Toast.makeText(PMContext, "Redirecting to login...", Toast.LENGTH_LONG).show();
                                        try {
                                            Thread.sleep(3000);
                                        } catch (InterruptedException e) {

                                        }
                                        mAuth.signOut();
                                        menu_manager.goToActivity(ProfileActivity.this, SplashActivity.class, null);
                                    }
                                    else{

                                        String keys[] = new String[1];
                                        String children[][] = new String[1][1];
                                        Object[][] values = new Object[1][1];

                                        keys[0] = mAuth.getUid();

                                        children[0][0] = "email";

                                        values[0][0] = emailAddress.getText().toString();

                                        //update data in users for the modified user
                                        DBManager.WriteData("users", true, keys, children, values);
                                    }
                                }
                            }, emailAddress.getText().toString(), "");
                        }

                        boolean bUpdateFL=false;
                        xFirstNameEnd=firstnameProfile.getText().toString();
                        xLastNameEnd=lastnameProfile.getText().toString();

                        if(!xFirstNameEnd.equals(xFirstNameStart) || !xLastNameEnd.equals(xLastNameStart)){
                            bUpdateFL=true;
                        }

                        if(bUpdateFL){
                            //update firstname and lastname

                            String keys[] = new String[1];
                            String children[][] = new String[1][2];
                            Object[][] values = new Object[1][2];

                            keys[0] = mAuth.getUid();

                            children[0][0] = "firstname";
                            children[0][1] = "lastname";

                            values[0][0] = firstnameProfile.getText().toString();
                            values[0][1] = lastnameProfile.getText().toString();

                            //update data in users for the modified user
                            DBManager.WriteData("users", true, keys, children, values);

                            Toast.makeText(PMContext, getString(R.string.PA_toast_ok), Toast.LENGTH_SHORT).show();
                        }

                    }

                    catch(Exception e) {
                        Log.e(TAG, "save_button onClick---Error updating user profile. Error: "+e);
                        Toast.makeText(PMContext, getString(R.string.PA_toast_ko), Toast.LENGTH_LONG).show();
                    }

                }

            }
        });

        // on load get profile image
        getImage();

        //on load get user info
        getUserInfo();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (actionBarDrawerToggle.onOptionsItemSelected(item)) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void pickImage(View view) {
        try{
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.setType("image/*");
            startActivityForResult(intent, PICK_IMAGE_REQUEST);
        }
        catch(Exception e){
            Log.e(TAG, "pickImage---Error: "+e);
        }
    }

    public void uploadImage() {
        try{
            progressDialog.setMessage("Uploading...");
            progressDialog.show();

            String userID=mAuth.getUid();

            storageReference = FirebaseStorage.getInstance().getReference();
            StorageReference imageRef = storageReference.child("images/" + userID + "/Profile_photo.jpg");

            imageRef.putFile(imageUri)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            progressDialog.dismiss();
                            getImage();
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            progressDialog.dismiss();
                            Log.e(TAG, "uploadImage---Upload failure. Error: "+e);
                        }
                    });

        }
        catch (Exception e){
            Log.e(TAG, "uploadImage---Error: "+e);
        }

    }

    public void getImage() {

        try{
            storageReferenceRead = FirebaseStorage.getInstance().getReference().child("images/"+mAuth.getUid()+"/Profile_photo.jpg");
            progressDialog = new ProgressDialog(this);

            ImageView imageView = findViewById(R.id.selectedImageView);

            storageReferenceRead.getDownloadUrl().addOnSuccessListener(uri -> {
                Glide.with(this)
                        .load(uri)
                        .into(imageView);
            }).addOnFailureListener(exception -> {
            });

        }
        catch(Exception e){
            Log.e(TAG, "getImage---Error: "+e);
        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            imageUri = data.getData();
            uploadImage();

        }
    }

    public void getUserInfo() {

        try{
            StorageReference storageReferenceRead = FirebaseStorage.getInstance().getReference().child("images/"+mAuth.getUid()+"/Profile_photo.jpg");
            ProgressDialog progressDialog = new ProgressDialog(this);

            ImageView imageView = menu_main.getHeaderView(0).findViewById(R.id.imageProfileMenu);

            storageReferenceRead.getDownloadUrl().addOnSuccessListener(uri -> {
                Glide.with(this)
                        .load(uri)
                        .into(imageView);
            }).addOnFailureListener(exception -> {
                Log.e(TAG, "getUserInfo---Error: "+exception.getMessage());
            });

        }
        catch(Exception e){
            Log.e(TAG, "getUserInfo---Error: "+e);
        }

        TextView nameProfile = menu_main.getHeaderView(0).findViewById(R.id.nameMenu);

        try {
            //get current user id
            String UserID=mAuth.getUid();

            //get url of database
            String DBUrl = DBManager.GetDBUrl();
            FirebaseDatabase database = FirebaseDatabase.getInstance(DBUrl);

            DatabaseReference reference=database.getReference("users");

            reference.child(UserID).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DataSnapshot> task) {

                    if(task.isSuccessful()){
                        DataSnapshot dataSnapshot= task.getResult();
                        String xFirstName=String.valueOf(dataSnapshot.child("firstname").getValue());
                        String xLastName=String.valueOf(dataSnapshot.child("lastname").getValue());
                        nameProfile.setText(xFirstName + " " + xLastName);
                    }
                }
            });
        }
        catch(Exception e) {
            Log.e(TAG, "Error reading data from user profile." +e);
        }

    }

}