package com.example.pm.adapters;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import com.example.pm.activities.ReminderActivity;
import com.example.pm.models.DBManager;
import com.example.pm.models.MenuManager;
import com.example.pm.models.MyReminders;
import com.example.progettopm.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class ReminderListAdapter extends RecyclerView.Adapter<ReminderListAdapter.ViewHolder> {
    private ArrayList<MyReminders> reminder_list;

    private Context PMContext;

    private ArrayList<MyReminders> allReminderList;

    private final static String TAG = ReminderListAdapter.class.getCanonicalName();

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private final TextView Title;
        private final TextView Amount;
        private final TextView Category;
        private final TextView CategoryExtra;
        private final TextView DateReminder;
        private final ImageButton ButtonEdit;
        private final ImageButton ButtonDone;

        public ViewHolder(View itemView) {
            super(itemView);

            Title = itemView.findViewById(R.id.eventTitle);
            Amount = itemView.findViewById(R.id.eventAmount);
            Category = itemView.findViewById(R.id.eventCategory);
            DateReminder = itemView.findViewById(R.id.eventDateReminder);
            CategoryExtra = itemView.findViewById(R.id.eventCategoryExtra);
            ButtonEdit = itemView.findViewById(R.id.buttonEdit);
            ButtonDone = itemView.findViewById(R.id.buttonDone);
        }
    }

    public ReminderListAdapter(ArrayList<MyReminders> pReminder_list, Context pContext) {
        this.reminder_list = pReminder_list;
        this.allReminderList=pReminder_list;
        this.PMContext = pContext;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.reminder_layout, parent, false);
        return new ViewHolder(itemView);
    }

    @Override
    public int getItemCount() {
        return reminder_list.size();
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        try {
            int xPosition = position;
            MyReminders currentReminder = reminder_list.get(position);
            holder.ButtonEdit.setTag(currentReminder.getId());
            holder.ButtonDone.setTag(currentReminder.getId());
            holder.Title.setText(currentReminder.getTitle());
            holder.Amount.setText(currentReminder.getAmount());
            holder.Category.setText(currentReminder.getCategory());
            holder.CategoryExtra.setText(currentReminder.getCategoryExtra());
            holder.DateReminder.setText(currentReminder.getDate());


            holder.ButtonEdit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    try{

                        MenuManager menu_manager=new MenuManager();
                        String xId = (String) view.getTag();

                        Bundle id = new Bundle();
                        id.putString("action", "EDIT");
                        id.putString("id", xId);

                        menu_manager.goToActivity(view.getContext(), ReminderActivity.class, id);

                    }
                    catch (Exception e){
                        Log.e(TAG, "Error trying to open ExpenseActivity. Error: "+e);
                    }
                }
            });

            // holder.ButtonDone

            holder.ButtonDone.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String id = (String) view.getTag();

                    Log.d(TAG, "Start deleting record id "+id );

                    DBManager.DeleteData("reminders", id,new DBManager.DeleteDataCallback() {

                        @Override
                        public void onDataDeleted(boolean pRetVal) {

                            if(pRetVal){
                                //if record deleted successfully alert user and refresh the reminders RecyclerView
                                Toast.makeText(view.getContext(), PMContext.getString(R.string.RLF_toast_ok), Toast.LENGTH_LONG).show();

                                //remove the item from dataset
                                if (xPosition != RecyclerView.NO_POSITION) {
                                    reminder_list.remove(xPosition);

                                    //notify the adapter that the data has changed
                                    notifyDataSetChanged();
                                }

                            }
                            else {
                                Toast.makeText(view.getContext(), PMContext.getString(R.string.RLF_toast_ko), Toast.LENGTH_LONG).show();
                            }

                        }
                    });


                }
            });
        }

        catch (Exception e) {
            Log.e(TAG, "ERROR in onBindViewHolder. Error: " + e) ;
        }

    }

    public void filter(String pCategory, int pMonth, String pYear) {

        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        ArrayList<MyReminders> filteredList = new ArrayList<>();

        for (MyReminders item : allReminderList) {
            try {
                Date xDate = dateFormat.parse(item.getDate());
                Calendar cal = Calendar.getInstance();
                cal.setTime(xDate);
                int xMonth = cal.get(Calendar.MONTH) + 1;
                String xYear = String.valueOf(cal.get(Calendar.YEAR));

                boolean categoryMatch = pCategory == null || item.getCategory().trim().equals(pCategory);
                boolean monthMatch = pMonth <= 0 || xMonth == pMonth;
                boolean yearMatch = pYear == null || xYear.trim().equals(pYear);

                if (categoryMatch && monthMatch && yearMatch) {
                    filteredList.add(item);
                }
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }

        reminder_list = filteredList.isEmpty() ? allReminderList : filteredList;

        if(pCategory!=null || pMonth!=0 || pYear!=null){
            reminder_list=filteredList;
        }

        notifyDataSetChanged();
    }
}
